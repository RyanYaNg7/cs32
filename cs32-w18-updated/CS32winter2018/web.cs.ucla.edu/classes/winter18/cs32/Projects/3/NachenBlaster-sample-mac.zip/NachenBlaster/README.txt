To run NachenBlaster:

1. Locate the folder NachenBlaster, which should have in it files named
NachenBlaster and Assets.  It's likely that the path to the folder will be
/Users/yourname/NachenBlaster or /Users/yourname/Downloads/NachenBlaster.

2. Open a Terminal window and type
	cd whateverThePathIs
where you should replace whateverThePathIs with the path to the NachenBlaster
folder.

3. Confirm you're in the right folder by typing
	ls
which should show you the Assets folder and the NachenBlaster executable.

4. Type
	./NachenBlaster
to play the game.  Use the arrow keys to move and the space bar to shoot.
You can type q to quit the game prematurely.

Alternatively, in the folder NachenBlaster, you can move the Assets folder
to your home directory, then double-click on the NachenBlaster executable
file.
